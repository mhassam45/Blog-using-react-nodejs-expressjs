const PostController = require('./PostController')
const VideoController = require('./VideoController')

module.exports = {

	post: PostController,
	video: VideoController

}
